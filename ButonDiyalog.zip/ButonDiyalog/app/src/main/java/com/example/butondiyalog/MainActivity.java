package com.example.butondiyalog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int[] rastgeleResimler = {
            R.drawable.bogaz, R.drawable.camlica, R.drawable.bestepesaray,
            R.drawable.alacati, R.drawable.anitkabir, R.drawable.efesantik,
            R.drawable.galata, R.drawable.tbmm, R.drawable.urla
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buton1 = findViewById(R.id.buton1);

        buton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                View diyalogTasarimi = getLayoutInflater().inflate(R.layout.ozel_diyalog, null);
                AlertDialog.Builder pencere = new AlertDialog.Builder(MainActivity.this);
                pencere.setView(diyalogTasarimi);
                AlertDialog goster = pencere.create();

                ImageView imgRastgele = diyalogTasarimi.findViewById(R.id.rastgeleResim);
                Button btnIst = diyalogTasarimi.findViewById(R.id.btnIstanbul);
                Button btnIzm = diyalogTasarimi.findViewById(R.id.btnIzmir);
                Button btnAnk = diyalogTasarimi.findViewById(R.id.btnAnkara);

                Random rastgele = new Random();
                int secilenIndex = rastgele.nextInt(rastgeleResimler.length);
                imgRastgele.setImageResource(rastgeleResimler[secilenIndex]);

                btnIst.setOnClickListener(v -> {
                    yeniSayfayaGec("İstanbul");
                    goster.dismiss();
                });

                btnIzm.setOnClickListener(v -> {
                    yeniSayfayaGec("İzmir");
                    goster.dismiss();
                });

                btnAnk.setOnClickListener(v -> {
                    yeniSayfayaGec("Ankara");
                    goster.dismiss();
                });

                goster.show();
            }
        });
    }

    private void yeniSayfayaGec(String secilenSehir) {
        Intent intent = new Intent(MainActivity.this, SehirDetayActivity.class);
        intent.putExtra("SEHIR_ADI", secilenSehir);
        startActivity(intent);
    }
}