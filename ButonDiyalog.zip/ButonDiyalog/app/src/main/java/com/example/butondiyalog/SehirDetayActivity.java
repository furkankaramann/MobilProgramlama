package com.example.butondiyalog;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SehirDetayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sehir_detay);

        TextView sehirBaslik = findViewById(R.id.sehirBaslik);

        ImageView gorsel1 = findViewById(R.id.gorsel1);
        TextView metin1 = findViewById(R.id.metin1);

        ImageView gorsel2 = findViewById(R.id.gorsel2);
        TextView metin2 = findViewById(R.id.metin2);

        ImageView gorsel3 = findViewById(R.id.gorsel3);
        TextView metin3 = findViewById(R.id.metin3);

        String gelenSehir = getIntent().getStringExtra("SEHIR_ADI");
        sehirBaslik.setText(gelenSehir);

        if (gelenSehir.equals("İstanbul")) {
            gorsel1.setImageResource(R.drawable.bogaz);
            metin1.setText("Boğaz");

            gorsel2.setImageResource(R.drawable.camlica);
            metin2.setText("Çamlıca Kulesi");

            gorsel3.setImageResource(R.drawable.galata);
            metin3.setText("Galata Kulesi");

        } else if (gelenSehir.equals("İzmir")) {
            gorsel1.setImageResource(R.drawable.urla);
            metin1.setText("Urla Plaj");

            gorsel2.setImageResource(R.drawable.efesantik);
            metin2.setText("Efes Antik Kenti");

            gorsel3.setImageResource(R.drawable.alacati);
            metin3.setText("Alaçatı");

        } else if (gelenSehir.equals("Ankara")) {
            gorsel1.setImageResource(R.drawable.bestepesaray);
            metin1.setText("Beştepe Sarayı");

            gorsel2.setImageResource(R.drawable.anitkabir);
            metin2.setText("Anıtkabir");

            gorsel3.setImageResource(R.drawable.tbmm);
            metin3.setText("Meclis");
        }
    }
}